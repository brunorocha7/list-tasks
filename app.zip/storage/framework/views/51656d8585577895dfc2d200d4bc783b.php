<?php $__env->startSection('title', 'Adicionar Tarefa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
      <h2>Cadastre uma nova Tarefa</h2>
      <hr>
      <form action="<?php echo e(route('tarefas-store')); ?>", method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
          <label for="">Nome:</label>
          <input type="text" class="form-control" name="nome" placeholder="Nome da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="">Descrição:</label>
          <input type="text" class="form-control" name="descricao" placeholder="Descrição da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="escolhe">Status:</label>
          <select class="form-control" name="status" id="escolha">
            <option value="Pendente">Pendente</option>
            <option value="Concluída">Concluída</option>
            <option value="Cancelada">Cancelada</option>
          </select>
        </div>
        <div class="form-group mt-3">
          <input type="submit" class="btn btn-primary" value="Cadastrar" mt-5>
        </div>
      </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bruno\Desktop\Teste Git Lista\ListaTarefas\resources\views/tarefas/create.blade.php ENDPATH**/ ?>