<?php $__env->startSection('title', 'Listagem Geral'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10">
                <h2>Tarefas</h2>
            </div>
            <div class="col-sm-2">
                <a href="<?php echo e(route('tarefas-create')); ?>" class="btn btn-success">Nova Tarefa</a>
            </div>
            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Título</th>
                      <th scope="col">Descrição</th>
                      <th scope="col">Status</th>
                      <th scope="col">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th><?php echo e($tf->id); ?></th>
                      <td><?php echo e($tf->nome); ?></td>
                      <td><?php echo e($tf->descricao); ?></td>
                      <td><?php echo e($tf->status); ?></td>
                      <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('tarefas-details', ['id' => $tf->id])); ?>" class="btn btn-info me-3">
                                <i class="bi bi-search"></i>
                            </a>
                            <a href="<?php echo e(route('tarefas-edit', ['id' => $tf->id])); ?>" class="btn btn-warning me-3">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <form action="<?php echo e(route('tarefas-destroy', ['id' => $tf->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
            </table>

        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bruno\Desktop\Teste Git Lista\ListaTarefas\resources\views/tarefas/index.blade.php ENDPATH**/ ?>