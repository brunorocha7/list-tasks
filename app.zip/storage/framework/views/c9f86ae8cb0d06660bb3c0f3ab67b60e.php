<?php $__env->startSection('title', 'Adicionar Tarefa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
      <h2>Atualizar Tarefa</h2>
      <hr>
      <form action="<?php echo e(route('tarefas-update', ['id' => $tarefas->id])); ?>", method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group mt-3">
          <label for="">Nome:</label>
          <input type="text" class="form-control" name="nome" value="<?php echo e($tarefas->nome); ?>" placeholder="Nome da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="">Descrição:</label>
          <input type="text" class="form-control" name="descricao" value="<?php echo e($tarefas->descricao); ?>" placeholder="Descrição da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="escolhe">Status:</label>
          <select class="form-control" name="status" id="escolha">
            <option value="<?php echo e($tarefas->status); ?>">Em andamento</option>
            <option value="Em andamento">Em andamento</option>
            <option value="Não iniciada">Não iniciada</option>
            <option value="Concluída">Concluída</option>
          </select>
        </div>
        <div class="form-group mt-3">
          <input type="submit" class="btn btn-success" value="Atualizar" mt-5>
        </div>
      </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bruno\Desktop\Teste Git Lista\ListaTarefas\resources\views/tarefas/edit.blade.php ENDPATH**/ ?>