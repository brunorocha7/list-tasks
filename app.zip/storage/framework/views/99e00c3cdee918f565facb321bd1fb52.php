<?php $__env->startSection('title', 'Adicionar Tarefa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
      <h2>Detalhes da Tarefa</h2>
      <hr>
        <?php echo method_field('put'); ?>
        <div class="form-group mt-3">
          <label for="">Nome:</label>
          <input type="text" class="form-control" name="nome" disabled value="<?php echo e($tarefas->nome); ?>" placeholder="Nome da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="">Descrição:</label>
          <input type="text" class="form-control" name="descricao" disabled value="<?php echo e($tarefas->descricao); ?>" placeholder="Descrição da Tarefa...">
        </div>
        <div class="form-group mt-3">
          <label for="escolhe">Status:</label>
          <select class="form-control" disabled name="status" id="escolha">
            <option value="<?php echo e($tarefas->status); ?>">Em andamento</option>
            <option value="Em andamento">Em andamento</option>
            <option value="Não iniciada">Não iniciada</option>
            <option value="Concluída">Concluída</option>
          </select>
        </div>
        <div class="form-group mt-3">
          <a href="<?php echo e(route('tarefas-index')); ?>" class="btn btn-success"  mt-5>Voltar</a>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bruno\Desktop\Teste Git Lista\ListaTarefas\resources\views/tarefas/details.blade.php ENDPATH**/ ?>